def main():
    print('Hi from any_node.')


if __name__ == '__main__':
    main()
