from setuptools import find_packages, setup

package_name = 'any_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(include=[package_name, package_name + ".*"]),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='kangjeonga',
    maintainer_email='kangjeonga@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'any_node = any_pkg.any_node:main',
            'atom_pub = any_pkg.atom_pub:main',
            'atom_sub = any_pkg.atom_sub:main',
        ],
    },
)
