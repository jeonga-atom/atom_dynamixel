import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32

class IntSubscriber(Node):
    def __init__(self):
        super().__init__('int_subscriber')  # 노드 이름 설정
        self.subscription = self.create_subscription(
            Int32,           # 메시지 타입
            'totopic',      # 구독할 토픽 이름
            self.callback,   # 콜백 함수
            10               # 큐 크기
        )
        self.subscription  # 변수를 유지하여 GC 방지

    def callback(self, msg):
        self.get_logger().info(f"Received: {msg.data}")  # 로그 출력

def main(args=None):
    rclpy.init(args=args)
    int_subscriber = IntSubscriber()

    try:
        rclpy.spin(int_subscriber)  # 노드 실행
    except KeyboardInterrupt:
        pass
    finally:
        int_subscriber.destroy_node()  # 노드 정리
        rclpy.shutdown()  # ROS 종료

if __name__ == '__main__':
    main()