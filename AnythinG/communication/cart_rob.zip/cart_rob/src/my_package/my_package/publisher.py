import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32
import time

class IntPublisher(Node):
    def __init__(self):
        super().__init__('int_publisher')  # 노드 이름 설정
        self.publisher = self.create_publisher(Int32, 'totopic', 10)  # 퍼블리셔 생성
        self.timer = self.create_timer(1.0, self.publish_message)  # 1초마다 실행되는 타이머 설정

    def publish_message(self):
        msg = Int32()
        msg.data = 42  # 전달할 데이터 값
        self.publisher.publish(msg)
        self.get_logger().info(f"Published: {msg.data}")  # 로그 출력

def main(args=None):
    rclpy.init(args=args)
    int_publisher = IntPublisher()

    try:
        rclpy.spin(int_publisher)  # 노드 실행 (이벤트 루프)
    except KeyboardInterrupt:
        pass
    finally:
        int_publisher.destroy_node()  # 노드 정리
        rclpy.shutdown()  # ROS 종료

if __name__ == '__main__':
    main()